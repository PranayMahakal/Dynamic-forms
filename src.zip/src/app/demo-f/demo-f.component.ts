import { Component, OnInit } from '@angular/core';
 import { FormGroup, FormBuilder,FormArray,ReactiveFormsModule ,FormControl,Validators, AbstractControl, ValidationErrors, ValidatorFn} from '@angular/forms';
 import { FormServiceService } from '../form-service.service';
@Component({
  selector: 'app-demo-f',
  templateUrl: './demo-f.component.html',
  styleUrls: ['./demo-f.component.css']
})
export class DemoFComponent implements OnInit {

  ​
 ​   dynamicForm=new FormGroup({});
    newFieldForm:FormGroup;
    showNewFieldForm:boolean=false;
    typeOptions: string[] = ['text', 'email', 'password', 'checkbox','dropdown','radiobox','number'];

   constructor(private formBuilder: FormBuilder,private formService: FormServiceService) {
    this.newFieldForm = this.formBuilder.group({
      type: ['', Validators.required],
      label: ['', Validators.required],
      name: ['', Validators.required],
      validations: this.formBuilder.array([]) // You might want to add validators for the new field
    });
    }
   formStructure:any=this.formService.getFormStructure();
   ngOnInit() {
  
    this.buildForm();
    this.buildNewFieldForm
   }

   buildForm(){
    const formStructure = this.formService.getFormStructure();
    
    const formGroup:{[key:string]:any}= {};
   

    formStructure.forEach(fieldData => {

     let controlValidators:ValidatorFn[] = [];
     ​
         if (fieldData.validations) {
           fieldData.validations.forEach((validation: { validator: string; }) => {
             if (validation.validator === 'required') controlValidators.push(Validators.required);
             if (validation.validator === 'email') controlValidators.push(Validators.email);
             
           });
         }
         
         const validators=Validators.compose(controlValidators);
      formGroup[fieldData.name] = [(fieldData.value || ''),validators];
      
    });
  ​
  this.dynamicForm  = this.formBuilder.group(formGroup);
   }
   buildNewFieldForm() {
    this.newFieldForm = this.formBuilder.group({
      type: ['', Validators.required],
      label: ['', Validators.required],
      name: ['', Validators.required],
      validations: this.formBuilder.array([]) // You might want to add validators for the new field
    });
  }
  toggleNewFieldForm() {
    this.showNewFieldForm = !this.showNewFieldForm;
    // if (!this.showNewFieldForm) {
    //   this.resetNewFieldForm();
    // }
  }

  toCamelCase(input: string): string {
    input=input.toLowerCase();
    console.log(input);
    
    input= input.replace(/\s(.)/g, ($1) => $1.toUpperCase())
                .replace(/\s/g, '')
                .replace(/^(.)/, ($1) => $1.toLowerCase());
             console.log(input);
             
                input=input.replace(/[\s_]+(.)/g, (_, chr) => chr.toUpperCase());
  console.log(input);
  
                  // Use a regular expression to convert to camel case
                  // return input.replace(/[\s_]+(.?)/g, (_, chr) => chr.toUpperCase());
                 input=  input.replace(/[^a-zA-Z]+(.)/g, (_, chr) => chr.toUpperCase()); 
                 
                //  input[0].toLowerCase();
                //   input.replace(/[\s_]+(.?)/g, (_, chr) => chr ? chr.toLowerCase() : '');
  console.log(input);
  
                   return input;     
  }

  addField() {
    
    const newField = this.newFieldForm.value;
    
    newField.name= this.toCamelCase(newField.label)
    
    this.formService.addFormField(newField);
    this.buildForm(); // Rebuild the form after adding a new field
    this.resetNewFieldForm();
  }

  resetNewFieldForm() {
    this.newFieldForm.reset();
    this.showNewFieldForm=false;

  }
   // ...

deleteField(fieldName: string) {
  // Implement logic to delete the field data from your service or JSON data
  // For example, you might update the formStructure array or service data
  this.formService.deleteFormField(fieldName);

  // Rebuild the form after deleting the field
  this.buildForm();
}



   onSubmit() {
    console.log(this.dynamicForm.value);
  }

}
